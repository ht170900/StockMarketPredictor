<!--
Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.

SPDX-License-Identifier: curl
-->

# Internals

This directory contains documentation covering libcurl internals; APIs and
concepts that are useful for contributors and maintainers.

Public APIs are documented in the public documentation, not here.
